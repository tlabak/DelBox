package com.example.securedeliverypackage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;
import java.text.SimpleDateFormat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Date and Time
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm:ss");
        String currentDate = DateFormat.getDateInstance().format(calendar.getTime());
        String currentTime = simpleDateFormat.format(calendar.getTime());

        TextView editTextDate = findViewById(R.id.editTextDate);
        editTextDate.setText(currentDate);

        TextView editTextTime = findViewById(R.id.editTextTime);
        editTextTime.setText(currentTime);

        // Firebase
        DatabaseReference setDB = FirebaseDatabase.getInstance().getReference().child("1-set");

        // Lock State
        DatabaseReference lockDB = setDB.child("Servo State");
        TextView textLockState = findViewById(R.id.textLockState);
        lockDB.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);
                textLockState.setText(value);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        });

        // Box State
        DatabaseReference boxDB = setDB.child("Box State");
        TextView textBoxState = findViewById(R.id.textBoxState);
        boxDB.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);
                textBoxState.setText(value);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        });

        // Temperature
        DatabaseReference tempDB = setDB.child("Temperature");
        TextView textTemperature = findViewById(R.id.textTemperature);
        tempDB.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);
                textTemperature.setText(value);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        });

        // Lock Actuation
        /*buttonLock = (Button) findViewById(R.id.buttonLock);
        buttonLock.setOnClickerListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View V){
                // Check Servo Motor State

                // Locking -> Servo State: 90

                // Unlocking _> Servo State: 0

            }
        }); */
    }

    // Data Retrieval Methods
    private void getLockState() {

    }
    private void getBoxState() {

    }
    private void getTemperature() {

    }
    private void getServoState() {

    }
}